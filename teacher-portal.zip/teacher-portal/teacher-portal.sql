-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2024 at 07:46 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.2.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teacher-portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_students`
--

CREATE TABLE `tbl_students` (
  `id` int(11) NOT NULL,
  `student_name` varchar(250) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `marks` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_students`
--

INSERT INTO `tbl_students` (`id`, `student_name`, `subject_id`, `marks`, `created_at`, `updated_at`) VALUES
(2, 'Jaspreet Bumrah', 3, 99, '2024-07-23 07:56:28', '2024-07-23 17:03:56'),
(3, 'Virat Kohli', 3, 55, '2024-07-23 08:00:26', '2024-07-23 17:09:14'),
(11, 'Hardik Pandya', 5, 98, '2024-07-23 08:24:56', '2024-07-23 17:30:10'),
(15, 'Ajay Jadeja', 3, 90, '2024-07-23 14:50:12', '2024-07-23 17:07:37'),
(16, 'Rohit Sharma', 1, 100, '2024-07-23 14:53:14', '2024-07-23 17:09:52'),
(17, 'Rahul Dravid', 6, 60, '2024-07-23 14:54:14', '2024-07-23 15:22:33'),
(18, 'Rishabh Pant', 2, 90, '2024-07-23 14:57:42', '2024-07-23 17:09:44'),
(20, 'Smriti Mandhana', 2, 80, '2024-07-23 15:12:19', '2024-07-23 15:12:46');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subjects`
--

CREATE TABLE `tbl_subjects` (
  `id` int(11) NOT NULL,
  `subjects` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_subjects`
--

INSERT INTO `tbl_subjects` (`id`, `subjects`, `created_at`, `updated_at`) VALUES
(1, 'ENGLISH', '2024-07-23 04:24:30', '2024-07-23 04:24:30'),
(2, 'HINDI', '2024-07-23 04:24:51', '2024-07-23 04:24:51'),
(3, 'MATHS', '2024-07-23 04:24:51', '2024-07-23 04:24:51'),
(4, 'PHYSICS', '2024-07-23 04:25:06', '2024-07-23 04:25:06'),
(5, 'CHEMISTRY', '2024-07-23 04:25:39', '2024-07-23 04:25:39'),
(6, 'BIOLOGY', '2024-07-23 04:25:39', '2024-07-23 04:25:39');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_teachers`
--

CREATE TABLE `tbl_teachers` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `full_name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_teachers`
--

INSERT INTO `tbl_teachers` (`id`, `username`, `full_name`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'utkarsh_sharma_463', 'Utkarsh Sharma', 'utkarsha817@gmail.com', '$2y$10$oifcR.kvIBk2R/sKiWIU3uHHSk5Df8kaiXIjzqDmXnFVvCXBiroUm', '2024-07-22 17:13:52', '2024-07-22 17:13:52'),
(2, 'rahul_sharma_149', 'Rahul Sharma', 'rahul3232@gmail.com', '$2y$10$RVS2P44pGqou2veKbQ36L.glO6toow5mi7r6Iqs9Tz6b7RLWMt0iq', '2024-07-22 17:38:53', '2024-07-22 17:38:53'),
(3, 'anurag_553', 'Anurag', 'anurag01@gmail.com', '$2y$10$xUST8o59qyxKDWz9VQmKkerOgDneFDMAotPsQKqO9sAqyBcOrkl22', '2024-07-23 07:19:09', '2024-07-23 07:19:09'),
(4, 'riyan_711', 'Riyan', 'riyan01@gmail.com', '$2y$10$16P.ATsa2HKGcaez8rXTp.3.mlikJbU1DJ7QIBWawvdV2ck6MkTsu', '2024-07-23 07:20:36', '2024-07-23 07:20:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_students`
--
ALTER TABLE `tbl_students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_students_ibfk_1` (`subject_id`);

--
-- Indexes for table `tbl_subjects`
--
ALTER TABLE `tbl_subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_teachers`
--
ALTER TABLE `tbl_teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_students`
--
ALTER TABLE `tbl_students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbl_subjects`
--
ALTER TABLE `tbl_subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_teachers`
--
ALTER TABLE `tbl_teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_students`
--
ALTER TABLE `tbl_students`
  ADD CONSTRAINT `tbl_students_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `tbl_subjects` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `tbl_students_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `tbl_subjects` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
