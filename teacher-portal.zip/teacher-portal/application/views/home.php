<?php $this->load->view('includes/head');  ?>
<?php $this->load->view('includes/topbar');  ?>

<div class="container-fluid page-body-wrapper">



  <?php $this->load->view('includes/theme-settings'); ?>
  <?php $this->load->view('includes/sidebar'); ?>




  <div class="content-wrapper">
    <div class="card">
      <div class="card-body">
        <h4 class="card-title">Dashboard</h4>
        <h5 class="">Hello!, <?=$this->session->userdata('username');?>, Welcome to the Dashboard!</h5>
        
      </div>
    </div>
  </div>







  <?php $this->load->view('includes/footer'); ?>
  <?php $this->load->view('includes/script'); ?>