<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?= @$page ?></title>
  <!-- plugins:css -->

  <link rel="stylesheet" href="<?=base_url('assets/vendors/ti-icons/css/themify-icons.css'); ?>">

  <link rel="stylesheet" href="<?=base_url('assets/vendors/font-awesome/css/font-awesome.min.css'); ?>">
  <link rel="stylesheet" href="<?=base_url('assets/vendors/mdi/css/materialdesignicons.min.css')?>"/>
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?=base_url('assets/css/vertical-layout-light/style.css'); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?=base_url('assets/images/favicon.png'); ?>" />
</head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-center auth px-0">
        <div class="row w-100 mx-0">
          <div class="col-lg-4 mx-auto">
            <div class="auth-form-light text-left py-5 px-4 px-sm-5">
              <div class="brand-logo">
                <img src="<?=base_url('assets/images/logo.png');?>" alt="logo">
              </div>
              <h4>Hello! let's get started</h4>
              <h6 class="font-weight-light">Sign in to continue.</h6>
              <form class="pt-3" action="<?= base_url('Login/authLogin'); ?>" method="post">
                <?php if ($this->session->flashdata('error')): ?>
                  <div class="alert alert-danger"><?= $this->session->flashdata('error'); ?></div>
                <?php endif; ?>

                <?php if ($this->session->flashdata('success')): ?>
                  <div class="alert alert-success"><?= $this->session->flashdata('success') ?></div>
                <?php endif; ?>

                <?php if (isset($validation_errors) && $validation_errors): ?>
                  <div class="alert alert-danger"><?= $validation_errors; ?></div>
                <?php endif; ?>

                <div class="form-group position-relative">
                  <i class="mdi mdi-account position-absolute top-50 start-0 translate-middle-y ms-3" style="font-size: 1.5em;color: #747373;"></i>
                  <input type="text" class="form-control form-control-lg ps-5" id="username_email" placeholder="Username/Email" name="username_email" value="<?= set_value('username_email'); ?>" required>
                </div>
                <div class="form-group position-relative">
                  <i class="mdi mdi-lock position-absolute top-50 start-0 translate-middle-y ms-3" style="font-size: 1.5em; color: #747373;" id="passwordIcon"></i>
                  <input type="password" class="form-control form-control-lg ps-5" id="password" placeholder="Password" name="password" value="<?= set_value('password'); ?>" required>
                  <i class="mdi mdi-eye position-absolute top-50 end-0 translate-middle-y me-3 cursor-pointer" id="togglePassword" style="font-size: 1.5em; color: #747373;cursor: pointer;"></i>
                </div>

                <div class="mt-3 d-grid gap-2">
                  <button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" type="submit">LOGIN</button>
                </div>
                <div class="text-center mt-4 font-weight-light">
                  Don't have an account? <a href="<?= base_url('register'); ?>" class="text-primary">Register</a>
                </div>
              </form>



            </div>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const passwordInput = document.getElementById('password');
      const togglePassword = document.getElementById('togglePassword');
      const passwordIcon = document.getElementById('passwordIcon');

      togglePassword.addEventListener('click', function() {
        // Toggle the type attribute of the password input
        if (passwordInput.type === 'password') {
          passwordInput.type = 'text';
            // Change icon to "eye-off" to indicate password is visible
          togglePassword.classList.remove('mdi-eye');
          togglePassword.classList.add('mdi-eye-off');
        } else {
          passwordInput.type = 'password';
            // Change icon to "eye" to indicate password is hidden
          togglePassword.classList.remove('mdi-eye-off');
          togglePassword.classList.add('mdi-eye');
        }
      });
    });
  </script>

  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="<?=base_url('assets/vendors/js/vendor.bundle.base.js'); ?>"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="<?=base_url('assets/js/off-canvas.js'); ?>"></script>
  <script src="<?=base_url('assets/js/hoverable-collapse.js'); ?>"></script>
  <script src="<?=base_url('assets/js/template.js'); ?>"></script>
  <script src="<?=base_url('assets/js/settings.js'); ?>"></script>
  <script src="<?=base_url('assets/js/todolist.js'); ?>"></script>
  <!-- endinject -->
</body>

</html>