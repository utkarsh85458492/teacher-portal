
<!DOCTYPE html>
<html lang="en">


<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title><?=$page;?></title>
  <!-- plugins:css -->
  <!-- <link rel="stylesheet" href="<?=base_url('assets/vendors/feather/feather.css'); ?>"> -->
  <link rel="stylesheet" href="<?=base_url('assets/vendors/ti-icons/css/themify-icons.css'); ?>">

  <link rel="stylesheet" href="<?=base_url('assets/vendors/font-awesome/css/font-awesome.min.css'); ?>">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- <link rel="stylesheet" href="<?=base_url('assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css'); ?>"> -->
  <link rel="stylesheet" href="<?=base_url('assets/vendors/datatables.net-bs5/dataTables.bootstrap5.css'); ?>">

  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="<?=base_url('assets/css/vertical-layout-light/style.css'); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="<?=base_url('assets/images/favicon.png'); ?>" />
   <link rel="stylesheet" href="<?=base_url('assets/vendors/mdi/css/materialdesignicons.min.css')?>"/>
</head>

<body>
  <div class="container-scroller">