   
<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <ul class="nav">
    <li class="nav-item <?= @$title == 'Teacher Portal' ? 'active' : ''?>">
      <a class="nav-link" href="<?=base_url();?>">
        <i class="icon-grid menu-icon"></i>
        <span class="menu-title">Dashboard</span>
      </a>
    </li>
    <li class="nav-item <?= @$title == 'Manage Students' ? 'active' : ''?>">
      <a class="nav-link" href="<?=base_url('manage-students');?>">
        <i class="icon-cog menu-icon"></i>
        <span class="menu-title">Manage Students</span>
      </a>
    </li>

  </ul>
</nav>

<div class="main-panel">