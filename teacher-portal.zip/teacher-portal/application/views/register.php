<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title><?=$page;?></title>
	<link rel="stylesheet" href="<?= base_url('assets/vendors/ti-icons/css/themify-icons.css'); ?>">
	<link rel="stylesheet" href="<?= base_url('assets/vendors/font-awesome/css/font-awesome.min.css'); ?>">
    <link rel="stylesheet" href="<?=base_url('assets/vendors/mdi/css/materialdesignicons.min.css')?>"/>
	<link rel="stylesheet" href="<?= base_url('assets/css/vertical-layout-light/style.css'); ?>">
	<link rel="shortcut icon" href="<?= base_url('assets/images/favicon.png'); ?>" />
	<style type="text/css">
		.cursor-pointer{
			cursor: pointer;
			font-size: 1.5em;
			color: #747373;
			border: var(--bs-border-width) solid var(--bs-border-color);
			border-left: 0;
			padding: 0.775rem 10px;
			margin-right: 0!important;
		}
	</style>
</head>

<body>
	<div class="container-scroller">
		<div class="container-fluid page-body-wrapper full-page-wrapper">
			<div class="content-wrapper d-flex align-items-center auth px-0">
				<div class="row w-100 mx-0">
					<div class="col-lg-4 mx-auto">
						<div class="auth-form-light text-left py-5 px-4 px-sm-5">
							<div class="brand-logo">
								<img src="<?= base_url('assets/images/logo.png'); ?>" alt="logo">
							</div>
							<h4>New here?</h4>
							<h6 class="font-weight-light">Signing up is easy. It only takes a few steps</h6>
							


							<?php if ($this->session->flashdata('error')): ?>
								<div class="alert alert-danger">
									<?= $this->session->flashdata('error') ?>
								</div>
							<?php endif; ?>

							<?php if ($this->session->flashdata('success')): ?>
								<div class="alert alert-success">
									<?= $this->session->flashdata('success') ?>
								</div>
							<?php endif; ?>

							<?php if (isset($validation_errors) && $validation_errors): ?>
								<div class="alert alert-danger"><?= $validation_errors; ?></div>
							<?php endif; ?>

							<form class="pt-3" action="<?= base_url('Login/saveData'); ?>" method="post">
								<div class="form-group position-relative">
									<div class="input-group">
										<div class="input-group-prepend">
											<span class="input-group-text"><i class="mdi mdi-account"></i></span>
										</div>
										<input type="text" class="form-control form-control-lg" id="exampleInputUsername1" placeholder="Full Name" name="full_name" value="<?= set_value('full_name'); ?>" required>
									</div>
								</div>
								<div class="form-group position-relative">
									<div class="input-group">
										<div class="input-group-prepend">
											<span class="input-group-text"><i class="mdi mdi-email"></i></span>
										</div>
										<input type="email" class="form-control form-control-lg" id="exampleInputEmail1" placeholder="Email" name="email" value="<?= set_value('email'); ?>" required>
									</div>
								</div>
								<div class="form-group position-relative">
									<div class="input-group">
										<div class="input-group-prepend">
											<span class="input-group-text"><i class="mdi mdi-lock"></i></span>
										</div>
										<input type="password" class="form-control form-control-lg" id="password" placeholder="Password" name="password" value="<?= set_value('password'); ?>" style="margin-right: 42px; border-right: 0;" required>
										<i class="mdi mdi-eye position-absolute top-50 end-0 translate-middle-y me-3 cursor-pointer" id="togglePassword" style="font-size: 1.5em;color: #747373;"></i>
									</div>
								</div>
								<div class="form-group position-relative">
									<div class="input-group">
										<div class="input-group-prepend">
											<span class="input-group-text"><i class="mdi mdi-lock"></i></span>
										</div>
										<input type="password" class="form-control form-control-lg" id="cpassword" placeholder="Confirm Password" name="cpassword" value="<?= set_value('cpassword'); ?>" style="margin-right: 42px; border-right: 0;" required>
										<i class="mdi mdi-eye position-absolute top-50 end-0 translate-middle-y me-3 cursor-pointer" id="toggleCPassword" style="font-size: 1.5em;color: #747373;"></i>
									</div>
								</div>
								<div class="mt-3 d-grid gap-2">
									<button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" type="submit">REGISTER</button>
								</div>
								<div class="text-center mt-4 font-weight-light">
									Already have an account? <a href="<?= base_url('login'); ?>" class="text-primary">Login</a>
								</div>
							</form>

							<script>
								document.addEventListener('DOMContentLoaded', function() {
									const passwordField = document.getElementById('password');
									const togglePassword = document.getElementById('togglePassword');
									const cpasswordField = document.getElementById('cpassword');
									const toggleCPassword = document.getElementById('toggleCPassword');

									togglePassword.addEventListener('click', function() {
										const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
										passwordField.setAttribute('type', type);
										this.classList.toggle('mdi-eye');
										this.classList.toggle('mdi-eye-off');
									});

									toggleCPassword.addEventListener('click', function() {
										const type = cpasswordField.getAttribute('type') === 'password' ? 'text' : 'password';
										cpasswordField.setAttribute('type', type);
										this.classList.toggle('mdi-eye');
										this.classList.toggle('mdi-eye-off');
									});
								});
							</script>




						</div>
					</div>
				</div>
			</div>
			<!-- content-wrapper ends -->
		</div>
		<!-- page-body-wrapper ends -->
	</div>



 
	<script src="<?= base_url('assets/vendors/js/vendor.bundle.base.js'); ?>"></script>
 
	<script src="<?= base_url('assets/js/off-canvas.js'); ?>"></script>
	<script src="<?= base_url('assets/js/hoverable-collapse.js'); ?>"></script>
	<script src="<?= base_url('assets/js/template.js'); ?>"></script>
	<script src="<?= base_url('assets/js/settings.js'); ?>"></script>
	<script src="<?= base_url('assets/js/todolist.js'); ?>"></script>
 
</body>
</html>