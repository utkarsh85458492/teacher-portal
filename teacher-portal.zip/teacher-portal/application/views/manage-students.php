<?php $this->load->view('includes/head');  ?>
<?php $this->load->view('includes/topbar');  ?>

<div class="container-fluid page-body-wrapper">
  <style type="text/css">

/* Remove the up/down arrows from number input */
input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

input[type=number] {
  -moz-appearance: textfield; /* Firefox */
}


select.no-arrow {
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  background: none;
  background-image: none;
  padding-right: 10px;
  background-color: white;
}

select.no-arrow::-ms-expand {
  display: none;
}

select.no-arrow:focus {
  outline: none;
}



</style>



<?php $this->load->view('includes/theme-settings'); ?>
<?php $this->load->view('includes/sidebar'); ?>




<div class="content-wrapper">
  <div class="card">
    <div class="card-body">
      <h4 class="card-title">Students List</h4>
      <button class="btn btn-outline-danger mb-3" data-bs-toggle="modal" data-bs-target="#addModal" style="padding: 9px 12px;">Add Student <i class="mdi mdi-account-plus"></i></button>
      <div class="row">

        <div class="col-12">
          <div class="table-responsive">

            <table id="order-listing" class="table">
              <thead>
                <tr>
                  <th>Id #</th>
                  <th>Student Name</th>
                  <th>Subject Name</th>
                  <th>Marks</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="studentList">
               <?php foreach ($students as $key => $value) { ?>
                <tr>
                  <td><?= $value['id']; ?></td>
                  <td data-column="student_name"><?= $value['student_name']; ?></td>
                  <td data-column="subject_name">
                   <span><?= $value['subject_name'] ?></span>
                   <select class="form-select no-arrow" id="editSubject_<?= $value['id']; ?>" data-id="<?= $value['id']; ?>" data-column="subject_name" style="outline: 1px solid #ffffff;">
                    <?php foreach ($subjects as $subject) { ?>
                      <option value="<?= $subject['id'] ?>" <?= $value['subject_id'] == $subject['id'] ? 'selected' : ''; ?>><?= $subject['subjects'] ?></option>
                    <?php } ?>
                  </select>
                </td>
                <td data-column="marks"><?= $value['marks']; ?></td>
                <td>
                  <button class="btn btn-outline-primary edit-btn" data-bs-toggle="modal" data-bs-target="#editModal" data-id="<?= $value['id']; ?>" data-student-name="<?= $value['student_name']; ?>" data-subject-id="<?= $value['subject_id']; ?>" data-marks="<?= $value['marks']; ?>" style="padding: 9px 12px;">Edit <i class="mdi mdi-pencil"></i></button>
                  <button class="btn btn-outline-danger delete-btn" data-id="<?= $value['id']; ?>" style="padding: 9px 12px;">Delete <i class="mdi mdi-delete"></i></button>
                </td>
              </tr>
            <?php } ?>

          </tbody>
        </table>

      </div>
    </div>
  </div>
</div>
</div>
</div>


<!-- add modal -->

<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Details</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">

        <div class="form-group">
          <label for="student_name">Student Name</label>
          <input type="text" class="form-control p-input" id="student_name" placeholder="Student Name">
        </div>
        <div class="form-group">
          <label for="subject_id">Subjects</label>
          <select class="form-select form-select-lg p-input" id="subject_id">
            <?php foreach ($subjects as $key => $value) { ?>
              <option value="<?=$value['id']?>"><?= $value['subjects'] ;?></option>
            <?php } ?>
          </select>
        </div>
        <div class="form-group">
          <label for="marks">Marks</label>
          <input type="number" class="form-control p-input" id="marks" placeholder="Marks">
        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="saveChangesButton">Save changes</button>
      </div>
    </div>
  </div>
</div>

<!-- Add Modal Ends-->






<!-- Edit Modal Start-->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Details</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="editForm">
          <input type="hidden" id="editId">
          <div class="form-group">
            <label for="editStudentName">Student Name</label>
            <input type="text" class="form-control" id="editStudentName" placeholder="Student Name">
          </div>
          <div class="form-group">
            <label for="editSubject">Subjects</label>
            <select class="form-select" id="editSubject">
              <!-- Options will be populated dynamically -->
              <?php foreach ($subjects as $subject) { ?>
                <option value="<?= $subject['id'] ?>"><?= $subject['subjects'] ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group">
            <label for="editMarks">Marks</label>
            <input type="number" class="form-control" id="editMarks" placeholder="Marks">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" id="updateButton">Save changes</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Edit Modal Ends-->



<script>
  document.addEventListener('DOMContentLoaded', function() {


    // Add Student Script

    document.getElementById('saveChangesButton').addEventListener('click', function() {
      const studentName = document.getElementById('student_name').value;
      const subjectId = document.getElementById('subject_id').value;
      const marks = document.getElementById('marks').value;

      const data = {
        student_name: studentName,
        subject_id: subjectId,
        marks: marks
      };

      fetch('<?= base_url('Home/AddStudent'); ?>', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(data)
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {

          const modal = bootstrap.Modal.getInstance(document.getElementById('addModal'));
          modal.hide();


          if (data.action == 'inserted') {
            const tableBody = document.getElementById('studentList');
            const newRow = document.createElement('tr');

            newRow.innerHTML = `
            <td>${data.students[data.students.length - 1].id}</td>
            <td>${data.students[data.students.length - 1].student_name}</td>
            <td>${data.students[data.students.length - 1].subject_name}</td>
            <td>${data.students[data.students.length - 1].marks}</td>
            <td>
            <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editModal" style="padding:9px 12px">Edit <i class="mdi mdi-pencil"></i></button>
            <button class="btn btn-outline-primary" style="padding:9px 12px" onclick="deleteStudent(${data.students[data.students.length - 1].id})">Delete <i class="mdi mdi-delete"></i></button>
            </td>
            `;

            tableBody.appendChild(newRow);
          } else {
            const rows = document.querySelectorAll('#studentList tr');
            rows.forEach(row => {
              const rowName = row.querySelector('td:nth-child(2)').innerText.trim();
              if (rowName === studentName) {
                row.querySelector('td:nth-child(2)').innerText = studentName;
                row.querySelector('td:nth-child(3)').innerText = data.subject_name; 
                row.querySelector('td:nth-child(4)').innerText = marks;
              }
            });
          }


          swal({
            title: 'Done',
            text: data.message,
            icon: 'success',
            button: {
              text: 'OK',
              value: true,
              visible: true,
              className: 'btn btn-primary',
              closeModal: true
            }
          }).then((value) => {
            if (value) {
              location.reload();
            }
          });



        } else {
          swal({
            title: 'Error',
            text: data.message,
            icon: 'warning',
            button: {
              value: true,
              visible: true,
              className: "btn btn-primary"
            }
          }).then((value) => {
            if (value) {
              location.reload();
            }
          });
        }
      })
      .catch(error => console.error('Error:', error));
    });




  // Edit Student Script


    document.querySelectorAll('#studentList td[data-column]').forEach(cell => {
      const select = cell.querySelector('select[data-column]');
      const span = cell.querySelector('span');

      if (select) {
    // Initially hide the select dropdown
        select.style.display = 'none';

    // Show dropdown on double-click
        cell.addEventListener('dblclick', function() {
      // Ensure span is hidden and select is shown
          if (span) {
            span.style.display = 'none';
          }
          select.style.display = 'block';
      select.removeAttribute('disabled'); // Make the select editable
      select.focus();
      
      // Trigger the dropdown menu
      select.click(); // This opens the dropdown menu
    });

    // Hide dropdown if user clicks outside
        document.addEventListener('click', function(event) {
          if (!select.contains(event.target) && !cell.contains(event.target)) {
            select.style.display = 'none';
            if (span) {
          span.style.display = ''; // Show the span again
        }
        select.setAttribute('disabled', 'true'); // Make the select non-editable again
      }
    });
      }
    });





    document.querySelectorAll('#studentList td[data-column]').forEach(cell => {
      if (cell.getAttribute('data-column') !== 'subject_name') {
        cell.addEventListener('dblclick', function() {
          if (!cell.classList.contains('editable')) {
            makeEditable(cell);
          }
        });
      }
    });

    document.querySelectorAll('.form-select[data-column="subject_name"]').forEach(select => {
      select.addEventListener('change', function() {
        const id = this.getAttribute('data-id');
        const newValue = this.value;
        saveDropdownChange(id, 'subject_id', newValue);
      });
    });

    function makeEditable(cell) {
      const originalContent = cell.innerText;
      const columnName = cell.getAttribute('data-column');
      cell.setAttribute('contenteditable', 'true');
      cell.classList.add('editable');
      cell.focus();

      cell.addEventListener('blur', function() {
        saveChanges(cell, originalContent, columnName);
      });

      cell.addEventListener('keydown', function(event) {
        if (event.key === 'Enter') {
          event.preventDefault();
          cell.blur();
        }
      });
    }

    function saveChanges(cell, originalContent, columnName) {
      const newContent = cell.innerText.trim();
      cell.setAttribute('contenteditable', 'false');
      cell.classList.remove('editable');

      if (newContent !== originalContent) {
        const row = cell.closest('tr');
        const id = row.querySelector('td:first-child').innerText;

        const data = {
          id: id,
          [columnName]: newContent
        };

        fetch('<?= base_url('Home/updateStudentQuickEdit'); ?>', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
          },
          body: JSON.stringify(data)
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            swal({
              title: 'Updated!',
              text: 'Student data has been updated.',
              icon: 'success',
              button: {
                text: 'OK',
                className: 'btn btn-primary'
              }
            }).then((value) => {
              if (value) {
                location.reload();
              }
            });
          } else {
            swal({
              title: 'Error!',
              text: data.message,
              icon: 'error',
              button: {
                text: 'OK',
                className: 'btn btn-primary'
              }
            }).then((value) => {
              if (value) {
                location.reload();
              }
            });
          }
        })
        .catch(error => console.error('Error:', error));
      }
    }

    function saveDropdownChange(id, columnName, newValue) {
      const data = {
        id: id,
        [columnName]: newValue
      };

      fetch('<?= base_url('Home/updateStudentQuickEdit'); ?>', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(data)
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          swal({
            title: 'Updated!',
            text: 'Student data has been updated.',
            icon: 'success',
            button: {
              text: 'OK',
              className: 'btn btn-primary'
            }
          }).then((value) => {
            if (value) {
              location.reload();
            }
          });
        } else {
          swal({
            title: 'Error!',
            text: data.message,
            icon: 'error',
            button: {
              text: 'OK',
              className: 'btn btn-primary'
            }
          }).then((value) => {
            if (value) {
              location.reload();
            }
          });
        }
      })
      .catch(error => console.error('Error:', error));
    }


  // Handle modal-based editing
    document.querySelectorAll('.edit-btn').forEach(button => {
      button.addEventListener('click', function() {
        const id = this.getAttribute('data-id');
        const studentName = this.getAttribute('data-student-name');
        const subjectId = this.getAttribute('data-subject-id');
        const marks = this.getAttribute('data-marks');

        document.getElementById('editId').value = id;
        document.getElementById('editStudentName').value = studentName;
        document.getElementById('editMarks').value = marks;

        const subjectSelect = document.getElementById('editSubject');
        Array.from(subjectSelect.options).forEach(option => {
          if (option.value === subjectId) {
            option.selected = true;
          }
        });
      });
    });

    document.getElementById('updateButton').addEventListener('click', function() {
      const id = document.getElementById('editId').value;
      const studentName = document.getElementById('editStudentName').value;
      const subjectId = document.getElementById('editSubject').value;
      const marks = document.getElementById('editMarks').value;

      const data = {
        id: id,
        student_name: studentName,
        subject_id: subjectId,
        marks: marks
      };

      fetch('<?= base_url('Home/updateStudent'); ?>', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(data)
      })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          const modal = bootstrap.Modal.getInstance(document.getElementById('editModal'));
          modal.hide();

          const rows = document.querySelectorAll('#studentList tr');
          rows.forEach(row => {
            const rowId = row.querySelector('td:first-child').innerText.trim();
            if (rowId === id) {
              row.querySelector('td:nth-child(2)').innerText = studentName;
            row.querySelector('td:nth-child(3)').innerText = data.subject_name; // Updated subject name from server response
            row.querySelector('td:nth-child(4)').innerText = marks;
          }
        });

          swal({
            title: 'Done',
            text: 'Student Data Updated Successfully!',
            icon: 'success',
            button: {
              value: true,
              visible: true,
              className: 'btn btn-primary'
            }
          }).then((value) => {
            if (value) {
              location.reload();
            }
          });
        } else {
          swal({
            title: 'Error',
            text: data.message,
            icon: 'warning',
            button: {
              value: true,
              visible: true,
              className: 'btn btn-primary'
            }
          }).then((value) => {
            if (value) {
              location.reload();
            }
          });
        }
      })
      .catch(error => console.error('Error:', error));
    });

  // Handle delete requests
    document.querySelectorAll('.delete-btn').forEach(button => {
      button.addEventListener('click', function() {
        const id = this.getAttribute('data-id');
        swal({
          title: 'Are you sure?',
          text: 'This action will delete the student data permanently!',
          icon: 'warning',
          buttons: true,
          dangerMode: true,
        }).then((willDelete) => {
          if (willDelete) {
            fetch('<?= base_url('Home/deleteStudent'); ?>', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
              },
              body: JSON.stringify({ id: id })
            })
            .then(response => response.json())
            .then(data => {
              if (data.success) {
                document.querySelector(`#studentList tr td:first-child:contains(${id})`).parentElement.remove();
                swal('Deleted!', 'Student data has been deleted.', 'success');
              } else {
                swal('Error!', data.message, 'error');
              }
            })
            .catch(error => console.error('Error:', error));
          }
        });
      });
    });





    // delete student script


    document.querySelectorAll('.delete-btn').forEach(button => {
      button.addEventListener('click', function() {
        const id = this.getAttribute('data-id');

        swal({
          title: 'Are you sure?',
          text: 'This action will delete the student data permanently!',
          icon: 'warning',
          buttons: {
            cancel: {
              text: 'Cancel',
              value: null,
              visible: true,
              className: 'btn btn-secondary',
              closeModal: true
            },
            confirm: {
              text: 'Yes, delete it!',
              value: true,
              visible: true,
              className: 'btn btn-primary',
              closeModal: true
            }
          }
        }).then((result) => {
          if (result) {
            fetch(`<?= base_url('Home/deleteStudent'); ?>`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
              },
              body: JSON.stringify({ id: id })
            })
            .then(response => response.json())
            .then(data => {
              if (data.success) {
                const rows = document.querySelectorAll('#studentList tr');
                rows.forEach(row => {
                  const firstCell = row.querySelector('td:first-child');
                  if (firstCell && firstCell.textContent.trim() === id) {
                    row.remove();
                  }
                });

                swal({
                  title: 'Deleted!',
                  text: 'Student data has been deleted.',
                  icon: 'success',
                  button: {
                    text: 'OK',
                    className: 'btn btn-primary' 
                  }
                }).then((value) => {
                  if (value) {
                    location.reload();
                  }
                });
              } else {
                swal({
                  title: 'Error!',
                  text: data.message,
                  icon: 'error',
                  button: {
                    text: 'OK',
                    className: 'btn btn-primary' 
                  }
                }).then((value) => {
                  if (value) {
                    location.reload();
                  }
                });
              }
            })
            .catch(error => console.error('Error:', error));
          }
        });
      });
    });


  // Validation for input type number Script

    const inputFields = document.querySelectorAll('input[type="number"]');
    inputFields.forEach(field => {
      field.addEventListener('keydown', function(event) {
        if (event.key === 'e' || event.key === '-' || event.key === 'E') {
          event.preventDefault();
        }
      });

      field.addEventListener('input', function(event) {
        this.value = this.value.replace(/[eE-]/g, '');
      });
    });




  });
</script>

<?php $this->load->view('includes/footer'); ?>
<?php $this->load->view('includes/script'); ?>