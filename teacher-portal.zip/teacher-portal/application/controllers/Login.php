<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->helper(array('form', 'url'));
		$this->load->model('User_model'); 
	}

	public function index()
	{
		$data['page'] = 'Login | Teacher Portal';
		$data['title'] = 'Login';
		$this->load->view('login', $data);
	}

public function authLogin() {
    $this->form_validation->set_rules('username_email', 'Username/Email', 'required|trim');
    $this->form_validation->set_rules('password', 'Password', 'required');

    if ($this->form_validation->run() == FALSE) {
        $data['validation_errors'] = validation_errors();
        $this->load->view('login', $data); // Pass validation errors to the view
    } else {
        $username_email = $this->input->post('username_email');
        $password = $this->input->post('password');

        $user = $this->User_model->get_user_by_username_or_email($username_email);

        if ($user && password_verify($password, $user['password'])) {
            $session_data = array(
                'user_id' => $user['id'],
                'username' => $user['username'],
                'logged_in' => TRUE,
            );
            $this->session->set_userdata($session_data);
            redirect(base_url());
        } else {
            $this->session->set_flashdata('error', 'Invalid username/email or password.');
            redirect('login');
        }
    }
}




	public function Logout() {
		$this->session->unset_userdata('user_id');
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('logged_in');
		$this->session->sess_destroy();

		$this->session->set_flashdata('success', 'You have been logged out successfully.');

		redirect('login');
	}


	public function Register()
	{
		$data['page'] = 'Register | Teacher Portal';
		$data['title'] = 'Register';
		$this->load->view('register', $data);
	}





	public function saveData() {
    $this->form_validation->set_rules('full_name', 'Full Name', 'required|trim');
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[tbl_teachers.email]');
    $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
    $this->form_validation->set_rules('cpassword', 'Confirm Password', 'required|matches[password]');

    if ($this->form_validation->run() == FALSE) {
        $data['validation_errors'] = validation_errors();
        $this->load->view('register', $data); // Pass validation errors to the view
    } else {
        $full_name = $this->input->post('full_name');
        $email = $this->input->post('email');
        $password = password_hash($this->input->post('password'), PASSWORD_BCRYPT);

        $username = $this->generateUsername($full_name);

        $data = array(
            'username' => $username,
            'full_name' => $full_name,
            'email' => $email,
            'password' => $password,
        );

        if ($this->User_model->insert_user($data)) {
            $this->session->set_flashdata('success', 'Registration successful! You can now log in.');
            redirect('login');
        } else {
            $this->session->set_flashdata('error', 'There was a problem registering your account. Please try again.');
            $this->load->view('register'); // Reload the view in case of an insertion error
        }
    }
}


	private function generateUsername($full_name) {
		$name_parts = explode(' ', $full_name);
		$username = strtolower(implode('_', $name_parts)) . '_' . rand(100, 999);
		return $username;
	}




}
