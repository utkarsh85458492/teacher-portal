<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct() {
		parent::__construct();
		if($this->session->userdata('logged_in') == FALSE){
			redirect(base_url('login'));
		}
		$this->load->model('User_model');
	}

	public function index()
	{
		$data['page'] = 'Home | Teacher Portal';
		$data['title'] = 'Teacher Portal';
		$this->load->view('home', $data);
	}


	public function ManageStudents(){
		$data['page'] = 'Manage Students | Teacher Portal';
		$data['title'] = 'Manage Students';

		$data['students'] = $this->User_model->getStudntsDat();
		$data['subjects'] = $this->User_model->getSubjects();
		$this->load->view('manage-students', $data);
	}

	public function AddStudent() {
		$input = json_decode($this->input->raw_input_stream, true);

		$studentName = $input['student_name'];
		$subjectId = $input['subject_id'];
		$marks = $input['marks'];

		$response = array('success' => false, 'message' => 'Failed to save data.');

		if ($studentName && $subjectId && $marks) {

			$existingStudent = $this->User_model->get_student_by_name_and_subject($studentName, $subjectId);

			if ($existingStudent) {

				$updateData = array('marks' => $marks);

				if ($this->User_model->update_student($existingStudent['id'], $updateData)) {
					$subjectName = $this->User_model->get_subject_name_by_id($subjectId);
					$response = array('success' => true, 'message' => 'Marks updated successfully.', 'subject_name' => $subjectName, 'action' => 'updated');
				}
			} else {

				$data = array(
					'student_name' => $studentName,
					'subject_id' => $subjectId,
					'marks' => $marks
				);

				if ($this->User_model->insert_student($data)) {
					$students = $this->User_model->get_all_students();
					$response = array('success' => true, 'message' => 'Data saved successfully.', 'students' => $students, 'action' => 'inserted');
				}
			}
		} else {
			$response['message'] = 'Please provide all required fields.';
		}

		echo json_encode($response);
	}



	public function updateStudent() {
		$this->load->model('User_model');

    // Get the raw POST data from the request
		$input = json_decode($this->input->raw_input_stream, true);

    // Validate input data
		$id = $input['id'];
		$studentName = $input['student_name'];
		$subjectId = $input['subject_id'];
		$marks = $input['marks'];

    // Initialize response
		$response = array('success' => false, 'message' => 'Failed to update data.');

		if ($id && $studentName && $subjectId && $marks) {
        // Prepare data for update
			$data = array(
				'student_name' => $studentName,
				'subject_id' => $subjectId,
				'marks' => $marks
			);

        // Update data in the database
			if ($this->User_model->update_student($id, $data)) {
            // Fetch updated subject name
				$subjectName = $this->User_model->get_subject_name_by_id($subjectId);
				$response = array('success' => true, 'message' => 'Data updated successfully.', 'subject_name' => $subjectName);
			}
		} else {
			$response['message'] = 'Please provide all required fields.';
		}

    // Output response as JSON
		echo json_encode($response);
	}




	public function updateStudentQuickEdit() {
  $input = json_decode($this->input->raw_input_stream, true);

  $id = $input['id'];
  $studentName = $input['student_name'] ?? null;
  $subjectId = $input['subject_id'] ?? null;
  $marks = $input['marks'] ?? null;

  $response = array('success' => false, 'message' => 'Failed to update data.');

  if ($id && ($studentName || $subjectId || $marks)) {
    $data = array();
    if ($studentName) $data['student_name'] = $studentName;
    if ($subjectId) $data['subject_id'] = $subjectId;
    if ($marks) $data['marks'] = $marks;

    if ($this->User_model->update_student($id, $data)) {
      $response = array('success' => true, 'message' => 'Data updated successfully.');
    }
  } else {
    $response['message'] = 'Please provide all required fields.'.$subjectId;
  }

  echo json_encode($response);
}







	public function deleteStudent()
	{
		$input = json_decode($this->input->raw_input_stream, true);
		if ($input) {
        // Get the student ID from the POST request
			$id = $input['id'];

        // Call the model method to delete the student record
			$deleted = $this->User_model->delete_student_by_id($id);

        // Check if the delete operation was successful
			if ($deleted) {
            // Send a JSON response indicating success
				echo json_encode(array('success' => true));
			} else {
            // Send a JSON response indicating failure
				echo json_encode(array('success' => false, 'message' => 'Failed to delete the student.'));
			}
		} else {
        // Send a JSON response indicating invalid request
			echo json_encode(array('success' => false, 'message' => 'Invalid request.'));
		}
	}




}
