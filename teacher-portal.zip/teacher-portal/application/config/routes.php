<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['default_controller'] = 'Home';

$route['login'] = 'Login';
$route['logout'] = 'Login/Logout';
$route['auth-login'] = 'Login/authLogin';
$route['register'] = 'Login/Register';
$route['manage-students'] = 'Home/ManageStudents';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
