<?php

defined('BASEPATH') or exit('No direct script access allowed');

function sendEmail($to,$subject,$msg)
{
	ini_set('display_errors',1);
	error_reporting( E_ALL );
	$from ="mgss.harshna@gmail.com";
	$to=$to;
	$subject=$subject;
	$msg=$msg;
	$headers="From:". $from;
   //$headers .= "Content-Type: text/html; charset=UTF-8\r\n";
	if(mail($to,$subject,$msg,$headers)){
		return 1;
	}else{
		return $to;
	}
}
