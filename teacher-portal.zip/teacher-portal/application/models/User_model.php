<?php
class User_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function insert_user($data) {
        return $this->db->insert('tbl_teachers', $data);
    }

    public function get_user_by_username_or_email($username_email) {
        $this->db->where('username', $username_email);
        $this->db->or_where('email', $username_email);
        $query = $this->db->get('tbl_teachers');
        return $query->row_array();
    }

    public function getStudntsDat(){



        $this->db->select('tbl_students.*, tbl_subjects.subjects as subject_name');
        $this->db->from('tbl_students');
        $this->db->join('tbl_subjects', 'tbl_students.subject_id = tbl_subjects.id');
        $res = $this->db->get();

        return $res->result_array();
    }


    public function getSubjects(){

        $res = $this->db->get('tbl_subjects');
        return $res->result_array();

    }


    public function insert_student($data){

     return $this->db->insert('tbl_students', $data);

 }

public function get_student_by_name_and_subject($studentName, $subjectId) {
    $this->db->where('student_name', $studentName);
    $this->db->where('subject_id', $subjectId);
    $query = $this->db->get('tbl_students');

    return $query->row_array();
}



 public function get_all_students() {
    $this->db->select('s.id, s.student_name, sub.subjects, s.marks');
    $this->db->from('tbl_students s');
    $this->db->join('tbl_subjects sub', 's.subject_id = sub.id');
    $query = $this->db->get();
    return $query->result_array();
}


public function update_student($id, $data) {
    $this->db->where('id', $id);
    return $this->db->update('tbl_students', $data);
}


public function get_subject_name_by_id($subjectId) {
    $this->db->select('subjects');
    $this->db->from('tbl_subjects');
    $this->db->where('id', $subjectId);
    $query = $this->db->get();
    $result = $query->row_array();
    return $result['subjects'];
}



public function delete_student_by_id($id)
{
    // Ensure that the ID is valid
    if (!empty($id) && is_numeric($id)) {
        // Use CodeIgniter's Query Builder to delete the record
        $this->db->where('id', $id);
        return $this->db->delete('tbl_students'); // Replace 'tbl_teachers' with your table name
    }
    return false;
}



}
